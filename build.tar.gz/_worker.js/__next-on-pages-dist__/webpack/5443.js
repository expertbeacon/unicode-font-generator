var c={},E=(_,b,x)=>(c.__chunk_5443=(v,d,i)=>{"use strict";i.d(d,{Z:()=>f});var o=i(8610);let h=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),n=(...e)=>e.filter((r,t,s)=>!!r&&s.indexOf(r)===t).join(" ");var m={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let u=(0,o.forwardRef)(({color:e="currentColor",size:r=24,strokeWidth:t=2,absoluteStrokeWidth:s,className:l="",children:a,iconNode:w,...N},g)=>(0,o.createElement)("svg",{ref:g,...m,width:r,height:r,stroke:e,strokeWidth:s?24*Number(t)/Number(r):t,className:n("lucide",l),...N},[...w.map(([k,p])=>(0,o.createElement)(k,p)),...Array.isArray(a)?a:[a]])),f=(e,r)=>{let t=(0,o.forwardRef)(({className:s,...l},a)=>(0,o.createElement)(u,{ref:a,iconNode:r,className:n(`lucide-${h(e)}`,s),...l}));return t.displayName=`${e}`,t}},c);export{E as __getNamedExports};
/**
* @license lucide-react v0.427.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
