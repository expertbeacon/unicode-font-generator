var t={},i=(l,o,y)=>(t.__chunk_8811=(x,n,e)=>{"use strict";e.d(n,{Z:()=>s});let s=(0,e(5443).Z)("Type",[["polyline",{points:"4 7 4 4 20 4 20 7",key:"1nosan"}],["line",{x1:"9",x2:"15",y1:"20",y2:"20",key:"swin9y"}],["line",{x1:"12",x2:"12",y1:"4",y2:"20",key:"1tx1rr"}]])},t);export{i as __getNamedExports};
/**
* @license lucide-react v0.427.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
