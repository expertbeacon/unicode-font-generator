# Square Text Generator

> Create Unique Aesthetic Fonts Online

Transform your text with a modern touch using our **Square Text Generator**! Perfect for adding a unique, geometric flair to your designs, this tool lets you create bold, square-shaped fonts that stand out.