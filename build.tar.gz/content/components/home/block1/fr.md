# Générateur de polices

> Générez facilement du texte stylé pour Facebook, X (anciennement Twitter) et d'autres plateformes de médias sociaux. Personnalisez les polices avec des styles gras, italiques, fantaisie et cool pour faire ressortir vos publications.
