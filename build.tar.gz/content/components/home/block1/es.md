# Generador de fuentes

> Genera fácilmente texto elegante para Facebook, X (anteriormente Twitter) y otras plataformas de redes sociales. Personaliza las fuentes con estilos en negrita, cursiva, elegantes y geniales para que tus publicaciones se destaquen.
