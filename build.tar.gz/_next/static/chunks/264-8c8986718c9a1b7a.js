"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[264],{9389:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("ALargeSmall",[["path",{d:"M21 14h-5",key:"1vh23k"}],["path",{d:"M16 16v-3.5a2.5 2.5 0 0 1 5 0V16",key:"1wh10o"}],["path",{d:"M4.5 13h6",key:"dfilno"}],["path",{d:"m3 16 4.5-9 4.5 9",key:"2dxa0e"}]])},9322:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Bold",[["path",{d:"M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8",key:"mg9rjx"}]])},8948:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Book",[["path",{d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",key:"k3hazp"}]])},4567:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Calculator",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",key:"1nb95v"}],["line",{x1:"8",x2:"16",y1:"6",y2:"6",key:"x4nwl0"}],["line",{x1:"16",x2:"16",y1:"14",y2:"18",key:"wjye3r"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M8 18h.01",key:"lrp35t"}]])},7519:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("CircleDot",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}]])},8165:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Circle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]])},6128:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Diamond",[["path",{d:"M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41l-7.59-7.59a2.41 2.41 0 0 0-3.41 0Z",key:"1f1r0c"}]])},807:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Feather",[["path",{d:"M12.67 19a2 2 0 0 0 1.416-.588l6.154-6.172a6 6 0 0 0-8.49-8.49L5.586 9.914A2 2 0 0 0 5 11.328V18a1 1 0 0 0 1 1z",key:"18jl4k"}],["path",{d:"M16 8 2 22",key:"vp34q"}],["path",{d:"M17.5 15H9",key:"1oz8nu"}]])},2177:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Gamepad2",[["line",{x1:"6",x2:"10",y1:"11",y2:"11",key:"1gktln"}],["line",{x1:"8",x2:"8",y1:"9",y2:"13",key:"qnk9ow"}],["line",{x1:"15",x2:"15.01",y1:"12",y2:"12",key:"krot7o"}],["line",{x1:"18",x2:"18.01",y1:"10",y2:"10",key:"1lcuu1"}],["path",{d:"M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",key:"mfqc10"}]])},4436:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]])},8649:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Hexagon",[["path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",key:"yt0hxn"}]])},1216:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Italic",[["line",{x1:"19",x2:"10",y1:"4",y2:"4",key:"15jd3p"}],["line",{x1:"14",x2:"5",y1:"20",y2:"20",key:"bu0au3"}],["line",{x1:"15",x2:"9",y1:"4",y2:"20",key:"uljnxc"}]])},7474:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Ligature",[["path",{d:"M8 20V8c0-2.2 1.8-4 4-4 1.5 0 2.8.8 3.5 2",key:"1rtphz"}],["path",{d:"M6 12h4",key:"a4o3ry"}],["path",{d:"M14 12h2v8",key:"c1fccl"}],["path",{d:"M6 20h4",key:"1i6q5t"}],["path",{d:"M14 20h4",key:"lzx1xo"}]])},5302:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]])},4501:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Palette",[["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",key:"12rzf8"}]])},5690:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("PenTool",[["path",{d:"M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z",key:"nt11vn"}],["path",{d:"m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18",key:"15qc1e"}],["path",{d:"m2.3 2.3 7.286 7.286",key:"1wuzzi"}],["circle",{cx:"11",cy:"11",r:"2",key:"xmgehs"}]])},8422:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]])},2092:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Smile",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 14s1.5 2 4 2 4-2 4-2",key:"1y1vjs"}],["line",{x1:"9",x2:"9.01",y1:"9",y2:"9",key:"yxxnd0"}],["line",{x1:"15",x2:"15.01",y1:"9",y2:"9",key:"1p4y9e"}]])},3907:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]])},1840:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("SquareDot",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}]])},2675:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Tv",[["rect",{width:"20",height:"15",x:"2",y:"7",rx:"2",ry:"2",key:"10ag99"}],["polyline",{points:"17 2 12 7 7 2",key:"11pgbg"}]])},5637:function(e,t,n){n.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.427.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,n(8030).Z)("Underline",[["path",{d:"M6 4v6a6 6 0 0 0 12 0V4",key:"9kb039"}],["line",{x1:"4",x2:"20",y1:"20",y2:"20",key:"nun2al"}]])},5758:function(e,t,n){var r=n(5332),a=n(6693);t.iV=r.default,a.default},8379:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(925),a=n(2265),l=n(294),i=n(8830),c=n(1165),o=a&&a.__esModule?a:{default:a};let u=a.forwardRef(function(e,t){let{locale:n,localePrefix:a,...u}=e,f=l.default(),d=n||f,h=i.getLocalePrefix(d,a);return o.default.createElement(c.default,r.extends({ref:t,locale:d,localePrefixMode:a.mode,prefix:h},u))});u.displayName="ClientLink",t.default=u},6693:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(925),a=n(2265),l=n(294),i=n(4463),c=n(6569),o=n(8379),u=n(4525),f=n(6148),d=n(1337),h=a&&a.__esModule?a:{default:a};t.default=function(e){let t=i.receiveLocalizedNavigationRoutingConfig(e);function n(){let e=l.default();if(!t.locales.includes(e))throw Error(void 0);return e}let y=a.forwardRef(function(e,a){let{href:l,locale:i,...u}=e,f=n(),d=i||f;return h.default.createElement(o.default,r.extends({ref:a,href:c.compileLocalizedPathname({locale:d,pathname:l,params:"object"==typeof l?l.params:void 0,pathnames:t.pathnames}),locale:i,localePrefix:t.localePrefix},u))});function p(e){let{href:n,locale:r}=e;return c.compileLocalizedPathname({...c.normalizeNameOrNameWithParams(n),locale:r,pathnames:t.pathnames})}return y.displayName="Link",{Link:y,redirect:function(e){let r=p({href:e,locale:n()});for(var a=arguments.length,l=Array(a>1?a-1:0),i=1;i<a;i++)l[i-1]=arguments[i];return u.clientRedirect({pathname:r,localePrefix:t.localePrefix},...l)},permanentRedirect:function(e){let r=p({href:e,locale:n()});for(var a=arguments.length,l=Array(a>1?a-1:0),i=1;i<a;i++)l[i-1]=arguments[i];return u.clientPermanentRedirect({pathname:r,localePrefix:t.localePrefix},...l)},usePathname:function(){let e=f.default(t.localePrefix),r=n();return a.useMemo(()=>e?c.getRoute(r,e,t.pathnames):e,[r,e])},useRouter:function(){let e=d.default(t.localePrefix),r=n();return a.useMemo(()=>({...e,push(t){for(var n,a=arguments.length,l=Array(a>1?a-1:0),i=1;i<a;i++)l[i-1]=arguments[i];let c=p({href:t,locale:(null===(n=l[0])||void 0===n?void 0:n.locale)||r});return e.push(c,...l)},replace(t){for(var n,a=arguments.length,l=Array(a>1?a-1:0),i=1;i<a;i++)l[i-1]=arguments[i];let c=p({href:t,locale:(null===(n=l[0])||void 0===n?void 0:n.locale)||r});return e.replace(c,...l)},prefetch(t){for(var n,a=arguments.length,l=Array(a>1?a-1:0),i=1;i<a;i++)l[i-1]=arguments[i];let c=p({href:t,locale:(null===(n=l[0])||void 0===n?void 0:n.locale)||r});return e.prefetch(c,...l)}}),[e,r])},getPathname:p}}},5332:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(925),a=n(2265),l=n(4463),i=n(8379),c=n(4525),o=n(6148),u=n(1337),f=a&&a.__esModule?a:{default:a};t.default=function(e){let t=l.receiveSharedNavigationRoutingConfig(e),n=a.forwardRef(function(e,n){return f.default.createElement(i.default,r.extends({ref:n,localePrefix:t.localePrefix},e))});return n.displayName="Link",{Link:n,redirect:function(e){for(var n=arguments.length,r=Array(n>1?n-1:0),a=1;a<n;a++)r[a-1]=arguments[a];return c.clientRedirect({pathname:e,localePrefix:t.localePrefix},...r)},permanentRedirect:function(e){for(var n=arguments.length,r=Array(n>1?n-1:0),a=1;a<n;a++)r[a-1]=arguments[a];return c.clientPermanentRedirect({pathname:e,localePrefix:t.localePrefix},...r)},usePathname:function(){return o.default(t.localePrefix)},useRouter:function(){return u.default(t.localePrefix)}}}},4525:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(294),a=n(5016);function l(e){return function(t){let n;try{n=r.default()}catch(e){throw e}for(var a=arguments.length,l=Array(a>1?a-1:0),i=1;i<a;i++)l[i-1]=arguments[i];return e({...t,locale:n},...l)}}let i=l(a.baseRedirect),c=l(a.basePermanentRedirect);t.clientPermanentRedirect=c,t.clientRedirect=i},6148:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(6463),a=n(2265),l=n(294),i=n(8830);t.default=function(e){let t=r.usePathname(),n=l.default();return a.useMemo(()=>{if(!t)return t;let r=i.getLocalePrefix(n,e);return i.hasPathnamePrefixed(r,t)?i.unprefixPathname(t,r):t},[n,e,t])}},1337:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(6463),a=n(2265),l=n(294),i=n(8830),c=n(9233),o=n(6569);t.default=function(e){let t=r.useRouter(),n=l.default(),u=r.usePathname();return a.useMemo(()=>{function r(t){return function(r,a){let{locale:l,...f}=a||{};c.default(u,n,l);let d=[function(t,r){let a=window.location.pathname,l=o.getBasePath(u);l&&(a=a.replace(l,""));let c=r||n,f=i.getLocalePrefix(c,e);return i.localizeHref(t,c,n,a,f)}(r,l)];return Object.keys(f).length>0&&d.push(f),t(...d)}}return{...t,push:r(t.push),replace:r(t.replace),prefetch:r(t.prefetch)}},[n,e,u,t])}},1165:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(925),a=n(7138),l=n(6463),i=n(2265),c=n(294),o=n(8830),u=n(9233);function f(e){return e&&e.__esModule?e:{default:e}}var d=f(a),h=f(i);let y=i.forwardRef(function(e,t){let{href:n,locale:a,localePrefixMode:f,onClick:y,prefetch:p,prefix:s,...m}=e,x=l.usePathname(),k=c.default(),v=a!==k,[g,P]=i.useState(()=>o.isLocalizableHref(n)&&("never"!==f||v)?o.prefixHref(n,s):n);return i.useEffect(()=>{x&&P(o.localizeHref(n,a,k,x,s))},[k,n,a,x,s]),v&&(p=!1),h.default.createElement(d.default,r.extends({ref:t,href:g,hrefLang:v?a:void 0,onClick:function(e){u.default(x,k,a),y&&y(e)},prefetch:p},m))});y.displayName="ClientLink",t.default=y},4463:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(5421);t.receiveLocalizedNavigationRoutingConfig=function(e){return{...e,localePrefix:r.receiveLocalePrefixConfig(null==e?void 0:e.localePrefix)}},t.receiveSharedNavigationRoutingConfig=function(e){return{...e,localePrefix:r.receiveLocalePrefixConfig(null==e?void 0:e.localePrefix)}}},5016:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(6463),a=n(8830);function l(e){return function(t){let n=a.getLocalePrefix(t.locale,t.localePrefix),r="never"!==t.localePrefix.mode&&a.isLocalizableHref(t.pathname)?a.prefixPathname(n,t.pathname):t.pathname;for(var l=arguments.length,i=Array(l>1?l-1:0),c=1;c<l;c++)i[c-1]=arguments[c];return e(r,...i)}}let i=l(r.redirect),c=l(r.permanentRedirect);t.basePermanentRedirect=c,t.baseRedirect=i},9233:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(4142),a=n(6569);t.default=function(e,t,n){if(!(n!==t&&null!=n)||!e)return;let l=a.getBasePath(e);document.cookie="".concat(r.COOKIE_LOCALE_NAME,"=").concat(n,"; path=").concat(""!==l?l:"/","; max-age=").concat(r.COOKIE_MAX_AGE,"; sameSite=").concat(r.COOKIE_SAME_SITE)}},6569:function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=n(8830);function a(e){let t=new URLSearchParams;for(let[n,r]of Object.entries(e))Array.isArray(r)?r.forEach(e=>{t.append(n,String(e))}):t.set(n,String(r));return"?"+t.toString()}t.compileLocalizedPathname=function(e){let{pathname:t,locale:n,params:r,pathnames:l,query:i}=e;function c(e){let t=l[e];return t||(t=e),t}function o(e){let t="string"==typeof e?e:e[n];return r&&Object.entries(r).forEach(e=>{let[n,r]=e;t=Array.isArray(r)?t.replace(RegExp("(\\[)?\\[...".concat(n,"\\](\\])?"),"g"),r.map(e=>String(e)).join("/")):t.replace("[".concat(n,"]"),String(r))}),i&&(t+=a(i)),t}if("string"==typeof t)return o(c(t));{let{pathname:e,...n}=t;return{...n,pathname:o(c(e))}}},t.getBasePath=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:window.location.pathname;return"/"===e?t:t.replace(e,"")},t.getRoute=function(e,t,n){let a=r.getSortedPathnames(Object.keys(n)),l=decodeURI(t);for(let t of a){let a=n[t];if("string"==typeof a){if(r.matchesPathname(a,l))return t}else if(r.matchesPathname(a[e],l))return t}return t},t.normalizeNameOrNameWithParams=function(e){return"string"==typeof e?{pathname:e}:e},t.serializeSearchParams=a},5421:function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.receiveLocalePrefixConfig=function(e){return"object"==typeof e?e:{mode:e||"always"}}},8830:function(e,t,n){var r=n(357);function a(e){return("object"==typeof e?null==e.host&&null==e.hostname:!/^[a-z]+:/i.test(e))&&!function(e){let t="object"==typeof e?e.pathname:e;return null!=t&&!t.startsWith("/")}(e)}function l(e,t){let n;return"string"==typeof e?n=i(t,e):(n={...e},e.pathname&&(n.pathname=i(t,e.pathname))),n}function i(e,t){let n=e;return/^\/(\?.*)?$/.test(t)&&(t=t.slice(1)),n+=t}function c(e,t){return t===e||t.startsWith("".concat(e,"/"))}function o(e){let t=function(){try{return"true"===r.env._next_intl_trailing_slash}catch(e){return!1}}();if("/"!==e){let n=e.endsWith("/");t&&!n?e+="/":!t&&n&&(e=e.slice(0,-1))}return e}function u(e){let t=e.replace(/\[\[(\.\.\.[^\]]+)\]\]/g,"?(.*)").replace(/\[(\.\.\.[^\]]+)\]/g,"(.+)").replace(/\[([^\]]+)\]/g,"([^/]+)");return new RegExp("^".concat(t,"$"))}function f(e){return e.includes("[[...")}function d(e){return e.includes("[...")}function h(e){return e.includes("[")}function y(e,t){let n=e.split("/"),r=t.split("/"),a=Math.max(n.length,r.length);for(let e=0;e<a;e++){let t=n[e],a=r[e];if(!t&&a)return -1;if(t&&!a)return 1;if(t||a){if(!h(t)&&h(a))return -1;if(h(t)&&!h(a))return 1;if(!d(t)&&d(a))return -1;if(d(t)&&!d(a))return 1;if(!f(t)&&f(a))return -1;if(f(t)&&!f(a))return 1}}return 0}Object.defineProperty(t,"__esModule",{value:!0}),t.getLocalePrefix=function(e,t){var n;return"never"!==t.mode&&(null===(n=t.prefixes)||void 0===n?void 0:n[e])||"/"+e},t.getSortedPathnames=function(e){return e.sort(y)},t.hasPathnamePrefixed=c,t.isLocalizableHref=a,t.localizeHref=function(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:t,r=arguments.length>3?arguments[3]:void 0,i=arguments.length>4?arguments[4]:void 0;if(!a(e))return e;let o=c(i,r);return(t!==n||o)&&null!=i?l(e,i):e},t.matchesPathname=function(e,t){let n=o(e),r=o(t);return u(n).test(r)},t.normalizeTrailingSlash=o,t.prefixHref=l,t.prefixPathname=i,t.templateToRegex=u,t.unprefixPathname=function(e,t){return e.replace(new RegExp("^".concat(t)),"")||"/"}}}]);